﻿#pragma once

void initializeConsole();
void function_game_start();
void function_story();
void function_game_over();